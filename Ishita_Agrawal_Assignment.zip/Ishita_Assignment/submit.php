<?php
header('Content-Type: application/json');

// Validation of email
if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['success' => false, 'message' => 'Invalid email format']);
    exit;
}

// Validate phone number
if (!preg_match('/^\d{10}$/', $_POST['phone'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid phone number format']);
    exit;
}

// Check for duplicate application
$email = $_POST['email'];

// Connection to the database
$conn = new mysqli('localhost', 'root', '', 'database1');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$stmt = $conn->prepare('SELECT id FROM applications WHERE email = ?');
$stmt->bind_param('s', $email);
$stmt->execute();
$stmt->store_result();
if ($stmt->num_rows > 0) {
    echo json_encode(['success' => false, 'message' => 'You have already applied for this job']);
    exit;
}
$stmt->close();

// Sanitize inputs and save application
$name = htmlspecialchars($_POST['name']);
$phone = htmlspecialchars($_POST['phone']);
$address = htmlspecialchars($_POST['address']);
$job = htmlspecialchars($_POST['job']);

// Handle resume upload
if ($_FILES['resume']['error'] === UPLOAD_ERR_OK) {
    $resume = $_FILES['resume'];
    $allowedTypes = ['application/pdf'];
    $maxSize = 2 * 1024 * 1024; // 2MB
    if (in_array($resume['type'], $allowedTypes) && $resume['size'] <= $maxSize) {
        $resumePath = 'uploads/' . basename($resume['name']);
        move_uploaded_file($resume['tmp_name'], $resumePath);
    } else {
        echo json_encode(['success' => false, 'message' => 'Invalid resume file type or size']);
        exit;
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Error uploading resume']);
    exit;
}

// Insert application into database
$stmt = $conn->prepare('INSERT INTO applications (name, email, phone, address, job, resume) VALUES (?, ?, ?, ?, ?, ?)');
$stmt->bind_param('ssssss', $name, $email, $phone, $address, $job, $resumePath);
$stmt->execute();
$stmt->close();
$conn->close();

// Fetch and display submitted data dynamically
ob_start();
?>
<div class="card">
    <div class="card-header">Submitted Application</div>
    <div class="card-body">
        <p><strong>Name:</strong> <?= $name ?></p>
        <p><strong>Email:</strong> <?= $email ?></p>
        <p><strong>Phone:</strong> <?= $phone ?></p>
        <p><strong>Address:</strong> <?= $address ?></p>
        <p><strong>Job:</strong> <?= $job ?></p>
        <p><strong>Resume:</strong> <a href="<?= $resumePath ?>" target="_blank">View Resume</a></p>
    </div>
</div>
<?php
$data = ob_get_clean();
echo json_encode(['success' => true, 'data' => $data]);
?>
