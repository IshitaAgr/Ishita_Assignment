$(document).ready(function() {
    $('#jobApplicationForm').on('submit', function(event) {
        event.preventDefault();

        // Client-side validation
        let form = this;
        if (form.checkValidity() === false) {
            event.stopPropagation();
            form.classList.add('was-validated');
            return;
        }

        // AJAX form submission
        let formData = new FormData(form);
        $.ajax({
            url: 'submit.php',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function(response) {
                if (response.success) {
                    Swal.fire('Success', 'Application submitted successfully!', 'success');
                    $('#submittedData').html(response.data);
                    form.reset();
                    form.classList.remove('was-validated');
                } else {
                    Swal.fire('Error', response.message, 'error');
                }
            },
            error: function() {
                Swal.fire('Error', 'There was an error submitting your application.', 'error');
            }
        });
    });
});
